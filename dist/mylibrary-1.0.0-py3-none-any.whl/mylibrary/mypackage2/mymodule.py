def hello():
    print("Hello from mypackage2.mymodule")